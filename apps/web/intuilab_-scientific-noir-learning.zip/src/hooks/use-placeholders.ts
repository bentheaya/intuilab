import { useState, useCallback } from 'react';

export interface Message {
  id: string;
  role: 'student' | 'mentor';
  content: string;
  timestamp: Date;
}

export function useSocraticChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'mentor',
      content: 'Welcome, seeker of knowledge. What phenomenon shall we explore today?',
      timestamp: new Date(),
    },
  ]);
  const [isTyping, setIsTyping] = useState(false);

  const sendMessage = useCallback(async (content: string) => {
    const newMessage: Message = {
      id: Math.random().toString(36).substring(7),
      role: 'student',
      content,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, newMessage]);
    setIsTyping(true);

    // Placeholder for AI response
    setTimeout(() => {
      const mentorResponse: Message = {
        id: Math.random().toString(36).substring(7),
        role: 'mentor',
        content: `Interesting perspective. How does that relate to the principle of conservation of energy?`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, mentorResponse]);
      setIsTyping(false);
    }, 1500);
  }, []);

  return { messages, sendMessage, isTyping };
}

export function useLessonProgress() {
  const [progress, setProgress] = useState(35);
  return { progress, setProgress };
}
