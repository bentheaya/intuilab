import React from 'react';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { SocraticSidebar } from '@/src/components/features/SocraticSidebar';
import { KnowledgeCheck } from '@/src/components/features/KnowledgeCheck';
import { MessageSquare, ChevronLeft, ChevronRight, Info } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { useLessonProgress } from '@/src/hooks/use-placeholders';
import { motion } from 'motion/react';

const markdownContent = `
# The Principle of Conservation of Energy

In physics and chemistry, the **law of conservation of energy** states that the total energy of an isolated system remains constant; it is said to be conserved over time.

Energy can neither be created nor destroyed; rather, it can only be transformed or transferred from one form to another. For instance, chemical energy is converted to kinetic energy when a stick of dynamite explodes.

## Mechanical Energy
In a frictionless system, the sum of potential energy ($U$) and kinetic energy ($K$) is constant:
$$E = K + U$$

Where:
- $K = \\frac{1}{2}mv^2$
- $U = mgh$
`;

export default function LessonPlayer() {
  const { progress } = useLessonProgress();

  return (
    <div classname="flex flex-col h-screen bg-background text-foreground overflow-hidden">
      {/* Header */}
      <header classname="h-16 border-b border-border flex items-center px-6 gap-6 bg-background/80 backdrop-blur-md z-20">
        <div classname="flex items-center gap-4">
          <button variant="ghost" size="icon" classname="text-muted-foreground hover:text-foreground">
            <chevronleft classname="w-5 h-5"/>
          </Button>
          <div classname="breadcrumb-style">
            Physics • Mechanics <span>Conservation of Energy</span>
          </div>
        </div>
        
        <div classname="flex-1 flex items-center gap-4 px-12">
          <progress value="{progress}" classname="h-1 bg-zinc-800"/>
          <span classname="text-[10px] font-mono text-muted-foreground">{progress}%</span>
        </div>

        <div classname="flex items-center gap-2">
          <button variant="outline" size="sm" classname="border-white/10 hover:bg-white/5 text-xs">
            <info classname="w-3.5 h-3.5 mr-2"/>
            Resources
          </Button>
          <div classname="lg:hidden">
            <sheet>
              <sheettrigger render="{&lt;Button" size="icon" classname="bg-blue-600 hover:bg-blue-500"/>}>
                <messagesquare classname="w-4 h-4"/>
              </SheetTrigger>
              <sheetcontent side="bottom" classname="h-[80vh] p-0 bg-zinc-950 border-white/10">
                <socraticsidebar/>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div classname="flex-1 flex overflow-hidden">
        {/* Left Column: Learning Canvas */}
        <main classname="flex-1 overflow-hidden flex flex-col">
          <scrollarea classname="flex-1">
            <div classname="max-w-4xl mx-auto p-8 space-y-12">
              {/* 3D Simulation Placeholder */}
              <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" opacity:="" 1,="" y:="" 0="" }}="" classname="aspect-video w-full rounded-2xl bg-zinc-900 border border-white/5 relative overflow-hidden group cursor-pointer shadow-[0_0_30px_rgba(59,130,246,0.15)]">
                <div classname="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-500/10 via-transparent to-transparent"/>
                <div classname="absolute inset-0 flex flex-col items-center justify-center gap-4">
                  <div classname="w-16 h-16 rounded-full bg-blue-600/20 flex items-center justify-center border border-blue-500/30 group-hover:scale-110 transition-transform neon-glow-physics">
                    <div classname="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center shadow-[0_0_20px_rgba(59,130,246,0.5)]">
                      <div classname="w-0 h-0 border-t-[8px] border-t-transparent border-l-[12px] border-l-white border-b-[8px] border-b-transparent ml-1"/>
                    </div>
                  </div>
                  <span classname="text-xs font-mono uppercase tracking-widest text-zinc-500">Initialize Three.js Simulation</span>
                </div>
                {/* Decorative Grid */}
                <div classname="absolute inset-0 opacity-10 pointer-events-none" style="{{" backgroundimage:="" 'radial-gradient(circle,="" #fff="" 1px,="" transparent="" 1px)',="" backgroundsize:="" '32px="" 32px'="" }}=""/>
              </motion.div>

              {/* Scientific Text */}
              <article classname="prose prose-invert max-w-none prose-headings:font-semibold prose-headings:tracking-tight prose-p:text-zinc-400 prose-p:leading-relaxed prose-strong:text-white">
                <reactmarkdown>{markdownContent}</ReactMarkdown>
              </article>

              {/* Knowledge Check */}
              <knowledgecheck question="If a pendulum is released from height H, what happens to its total mechanical energy at the lowest point of its swing (ignoring friction)?" options="{[" "it="" increases="" as="" kinetic="" energy="" increases",="" "it="" decreases="" as="" potential="" energy="" is="" lost",="" "it="" remains="" exactly="" the="" same",="" "it="" fluctuates="" based="" on="" the="" mass="" of="" the="" bob"="" ]}="" correctanswer="{2}"/>

              <div classname="h-24 flex items-center justify-between border-t border-white/5 pt-8">
                <button variant="ghost" classname="text-zinc-500 hover:text-white">
                  <chevronleft classname="w-4 h-4 mr-2"/>
                  Previous Concept
                </Button>
                <button classname="bg-blue-600 hover:bg-blue-500 px-8">
                  Next Concept
                  <chevronright classname="w-4 h-4 ml-2"/>
                </Button>
              </div>
            </div>
          </ScrollArea>
        </main>

        {/* Right Column: Socratic Tutor (Desktop) */}
        <aside classname="hidden lg:block w-[400px] border-l border-white/5">
          <socraticsidebar/>
        </aside>
      </div>
    </div>
  );
}
