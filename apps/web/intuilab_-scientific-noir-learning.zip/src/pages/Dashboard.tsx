import React from 'react';
import ReactFlow, { Background, Controls } from 'reactflow';
import 'reactflow/dist/style.css';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Flame, ArrowRight, Clock, BookOpen, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';

const initialNodes = [
  { id: '1', position: { x: 0, y: 0 }, data: { label: 'Classical Mechanics' }, style: { background: '#1e40af', color: '#fff', borderRadius: '12px', border: 'none', boxShadow: '0 0 20px rgba(59, 130, 246, 0.5)' } },
  { id: '2', position: { x: 200, y: -100 }, data: { label: 'Electromagnetism' }, style: { background: '#1e40af', color: '#fff', borderRadius: '12px', border: 'none' } },
  { id: '3', position: { x: 200, y: 100 }, data: { label: 'Thermodynamics' }, style: { background: '#1e40af', color: '#fff', borderRadius: '12px', border: 'none' } },
  { id: '4', position: { x: 400, y: 0 }, data: { label: 'Quantum Physics' }, style: { background: '#1e40af', color: '#fff', borderRadius: '12px', border: 'none', opacity: 0.5 } },
];

const initialEdges = [
  { id: 'e1-2', source: '1', target: '2', animated: true, style: { stroke: '#3b82f6' } },
  { id: 'e1-3', source: '1', target: '3', animated: true, style: { stroke: '#3b82f6' } },
  { id: 'e2-4', source: '2', target: '4', style: { stroke: '#3b82f6', strokeDasharray: '5,5' } },
];

export default function Dashboard() {
  return (
    <div classname="flex-1 relative flex flex-col bg-background overflow-hidden">
      {/* Header */}
      <header classname="h-16 border-b border-white/10 flex items-center justify-between px-6 bg-background/80 backdrop-blur-md z-40">
        <div classname="breadcrumb-style">
          Platform <span>Discovery Dashboard</span>
        </div>
        <div classname="flex items-center gap-5">
          <div classname="text-[13px] text-muted-foreground">
            Subject: <span classname="text-white">Theoretical Physics</span>
          </div>
          <div classname="w-8 h-8 rounded-full bg-zinc-800 border border-white/10"/>
        </div>
      </header>

      {/* Knowledge Map Area */}
      <div classname="flex-1 relative knowledge-map-bg">
        <div classname="absolute inset-0 map-grid opacity-50"/>
        
        {/* Connections (Simulated) */}
        <div classname="absolute w-[150px] h-px bg-gradient-to-r from-blue-500 to-red-500 opacity-30 left-[180px] top-[220px] rotate-[15deg] origin-left"/>
        <div classname="absolute w-[200px] h-px bg-gradient-to-r from-blue-500 to-red-500 opacity-30 left-[350px] top-[400px] -rotate-[30deg] origin-left"/>

        {/* Nodes (Simulated) */}
        <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" opacity:="" 1,="" y:="" 0="" }}="" classname="absolute left-20 top-[180px] node-pill neon-glow-physics">
          <div classname="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_#3b82f6]"/>
          <span classname="text-sm font-medium">Classical Mechanics</span>
        </motion.div>

        <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" opacity:="" 1,="" y:="" 0="" }}="" transition="{{" delay:="" 0.1="" }}="" classname="absolute left-[320px] top-[250px] node-pill neon-glow-physics">
          <div classname="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_#3b82f6]"/>
          <span classname="text-sm font-medium">Electromagnetism</span>
        </motion.div>

        <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" opacity:="" 1,="" y:="" 0="" }}="" transition="{{" delay:="" 0.2="" }}="" classname="absolute left-[200px] top-[450px] node-pill neon-glow-chemistry">
          <div classname="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444]"/>
          <span classname="text-sm font-medium">Thermodynamics</span>
        </motion.div>

        <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" opacity:="" 1,="" y:="" 0="" }}="" transition="{{" delay:="" 0.3="" }}="" classname="absolute left-[550px] top-[320px] node-pill opacity-50">
          <div classname="w-2 h-2 rounded-full bg-zinc-500"/>
          <span classname="text-sm font-medium">Quantum Electrodynamics</span>
        </motion.div>

        {/* Floating Widgets */}
        <div classname="absolute top-6 right-6 bottom-6 w-[300px] flex flex-col gap-5 pointer-events-none">
          {/* Daily Spark */}
          <motion.div initial="{{" opacity:="" 0,="" x:="" 20="" }}="" animate="{{" opacity:="" 1,="" x:="" 0="" }}="" classname="pointer-events-auto widget-geometric">
            <div classname="widget-title-geometric">
              Daily Spark
              <span classname="text-orange-500">🔥</span>
            </div>
            <div classname="flex items-center gap-2 text-2xl font-extrabold text-white">
              14 Days
            </div>
            <div classname="grid grid-cols-7 gap-1 mt-3">
              {[1, 1, 1, 1, 1, 0, 0].map((active, i) => (
                <div key="{i}" classname="{`h-1" rounded-sm="" ${active="" ?="" 'bg-green-500'="" :="" 'bg-white="" 10'}`}=""/>
              ))}
            </div>
          </motion.div>

          {/* Next Discovery */}
          <motion.div initial="{{" opacity:="" 0,="" x:="" 20="" }}="" animate="{{" opacity:="" 1,="" x:="" 0="" }}="" transition="{{" delay:="" 0.1="" }}="" classname="pointer-events-auto widget-geometric bg-gradient-to-br from-blue-500/10 to-transparent">
            <div classname="widget-title-geometric">Next Discovery</div>
            <h3 classname="text-lg font-semibold text-white mb-1">Wave-Particle Duality</h3>
            <p classname="text-xs text-muted-foreground mb-4">Path: Quantum Foundations • 12m read</p>
            <button render="{&lt;Link" to="/learn/physics/mechanics/angular-momentum"/>} 
              nativeButton={false}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold"
            >
              <div classname="flex items-center justify-center">
                Begin Rediscovery
              </div>
            </Button>
          </motion.div>

          {/* Recent Insights */}
          <motion.div initial="{{" opacity:="" 0,="" x:="" 20="" }}="" animate="{{" opacity:="" 1,="" x:="" 0="" }}="" transition="{{" delay:="" 0.2="" }}="" classname="pointer-events-auto widget-geometric">
            <div classname="widget-title-geometric">Recent Insights</div>
            <div classname="space-y-3">
              {[
                { title: 'Lorentz Transformation', meta: 'Portfolio #28 • 2h ago' },
                { title: 'Entropy as Information', meta: 'Portfolio #27 • Yesterday' },
                { title: 'Maxwell\'s Equations', meta: 'Portfolio #26 • 3 days ago' },
              ].map((insight, i) => (
                <div key="{i}" classname="pb-3 border-b border-white/5 last:border-0 last:pb-0">
                  <div classname="text-[13px] font-medium text-white">{insight.title}</div>
                  <div classname="text-[11px] text-muted-foreground">{insight.meta}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
