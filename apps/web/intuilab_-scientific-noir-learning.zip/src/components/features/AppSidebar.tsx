import React from 'react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { 
  BookOpen, 
  Map, 
  Beaker, 
  Briefcase, 
  Layers, 
  Settings, 
  LogOut,
  Sparkles
} from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";

const navItems = [
  { title: "Learn", icon: BookOpen, url: "/" },
  { title: "Knowledge Map", icon: Map, url: "/map" },
  { title: "Virtual Lab", icon: Beaker, url: "/lab" },
  { title: "Portfolio", icon: Briefcase, url: "/portfolio" },
  { title: "Flashcards", icon: Layers, url: "/flashcards" },
];

export function AppSidebar() {
  const location = useLocation();

  return (
    <sidebar classname="border-r border-white/10 bg-[#020202]">
      <sidebarheader classname="p-4 flex items-center justify-center">
        <div classname="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-lg shadow-[0_0_15px_rgba(59,130,246,0.5)]">
          S
        </div>
      </SidebarHeader>
      <sidebarcontent>
        <sidebargroup>
          <sidebargroupcontent classname="px-2">
            <sidebarmenu classname="gap-4">
              {navItems.map((item) => (
                <sidebarmenuitem key="{item.title}">
                  <sidebarmenubutton render="{&lt;Link" to="{item.url}"/>}
                    isActive={location.pathname === item.url}
                    className={cn(
                      "h-10 w-10 p-0 flex items-center justify-center rounded-lg transition-all",
                      location.pathname === item.url 
                        ? "bg-white/10 text-white shadow-[0_0_10px_rgba(255,255,255,0.1)] border border-white/10" 
                        : "text-zinc-500 hover:text-zinc-300"
                    )}
                    tooltip={item.title}
                  >
                    <item.icon classname="w-5 h-5"/>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <sidebarfooter classname="p-4 flex items-center justify-center">
        <div classname="w-8 h-8 rounded-full bg-zinc-800 border border-white/10"/>
      </SidebarFooter>
    </Sidebar>
  );
}
