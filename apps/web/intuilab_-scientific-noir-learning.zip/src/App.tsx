import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { TooltipProvider } from '@/components/ui/tooltip';
import { AppSidebar } from '@/src/components/features/AppSidebar';
import Dashboard from '@/src/pages/Dashboard';
import LessonPlayer from '@/src/pages/LessonPlayer';
import FeynmanChallenger from '@/src/pages/FeynmanChallenger';

export default function App() {
  return (
    <TooltipProvider>
      <Router>
        <SidebarProvider>
          <div className="flex min-h-screen w-full bg-zinc-950 text-zinc-100 dark">
            <AppSidebar />
            <SidebarInset className="flex flex-col bg-zinc-950">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/learn/:subject/:topic/:lesson" element={<LessonPlayer />} />
                <Route path="/feynman/:concept" element={<FeynmanChallenger />} />
                {/* Fallback to Dashboard for other routes in this demo */}
                <Route path="*" element={<Dashboard />} />
              </Routes>
            </SidebarInset>
          </div>
        </SidebarProvider>
      </Router>
    </TooltipProvider>
  );
}
